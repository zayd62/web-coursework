from django.contrib import admin
from .models import Profile, Bid, Auction

admin.site.register(Profile)
admin.site.register(Bid)
admin.site.register(Auction)
